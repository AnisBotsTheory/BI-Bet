# BI Paris Sportifs — squelette Streamlit

## Installation
```bash
pip install -r requirements.txt
cp .streamlit/secrets.toml.example .streamlit/secrets.toml
# puis compléter la clé API football dans ce fichier
streamlit run app.py
```

## Structure

```
sport_bi_app/
├── app.py                     # Accueil, statut global
├── pages/                     # Un fichier = un onglet (numéroté pour l'ordre d'affichage)
│   ├── 1_⚽_Football.py
│   ├── 2_🎾_Tennis.py
│   ├── 3_🐎_Hippique.py
│   ├── 4_🥊_MMA.py
│   ├── 5_💰_Suivi_Bankroll.py
│   └── 6_📖_Methodologie.py
├── core/                      # Socle mutualisé entre tous les sports
│   ├── schema.py               # Event / Participant / OddsSnapshot / Result
│   ├── rating_engine.py        # TrueSkill générique (duels ET classements à n)
│   └── probability.py          # Probabilité implicite depuis les cotes
├── sources/                   # UN connecteur par sport (décision volontaire)
│   ├── football_api.py         # API-Football
│   ├── tennis_source.py        # tennis-data.co.uk
│   ├── hippique_source.py      # open-pmu-api
│   └── mma_source.py           # Ultimate UFC Dataset (Kaggle, local)
├── features/                  # Features spécifiques par sport (à compléter)
└── data/cache/                 # Fichiers mis en cache localement (ex: dataset MMA)
```

## Principe de chaque page sport
Chaque onglet suit 3 blocs : **Ingestion** (statut de connexion) →
**Exploration** (aperçu de ce que la donnée permet) → **Sortie exploitable**
(rating + probabilité). Ça garde la même logique visible dans tous les sports
même si leur maturité de donnée diffère.

## Rappel des décisions prises
- **Une seule source par sport** : évite les problèmes de réconciliation
  d'identifiants entre fournisseurs différents (noms d'équipes, joueurs...).
- **Pas de temps réel** : rafraîchissement quotidien/hebdomadaire (`ttl` du
  cache Streamlit), pour limiter la responsabilité sur la véracité instantanée
  et éviter d'encourager les paris impulsifs.
- **TrueSkill comme moteur de rating unique** : gère nativement les duels
  (foot/tennis/MMA) et les classements à n participants (hippique).
